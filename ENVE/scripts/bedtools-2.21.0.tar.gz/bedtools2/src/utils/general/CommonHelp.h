/*
 * CommonHelpFile.h
 *
 *  Created on: Jul 2, 2014
 *      Author: nek3d
 */

#ifndef COMMONHELPFILE_H_
#define COMMONHELPFILE_H_

using namespace std;

#include <iostream>

extern void CommonHelp();



#endif /* COMMONHELPFILE_H_ */
