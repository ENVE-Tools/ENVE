/*
 * CommonHelp.cpp
 *
 *  Created on: Jul 2, 2014
 *      Author: nek3d
 */
#include "CommonHelp.h"

void CommonHelp() {
    cerr << "\t-iobuf\t"            << "Follow with desired integer size of read buffer." << endl;
    cerr << "\t\t" <<					"Optional suffixes K/M/G supported." << endl;
    cerr << "\t\t" 					<< "Note: currently has no effect with compressed files." << endl << endl;
}




